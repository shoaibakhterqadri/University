          HOW TO INSTALL DIJKSTRA SIMULATOR

Step No.1 Connect to the Internet and download the .Net Framework 3.5 offline installer according to your version of Windows. Select one (1) among the four(4) below:
  1.Net Framework 3.5 Offline Installer for Windows 7
    https://www.microsoft.com/en-ie/download/details.aspx?id=25150
    
  2.Net Framework 3.5 Offline Installer for Windows 8.0
    https://sourceforge.net/projects/framework-3-offline/files/Windows%208/Net%20Framework%203.5%20offline%20installer%20Win_8.zip/download
    
  3.Net Framework 3.5 Offline Installer for Windows 8.1
    https://sourceforge.net/projects/framework-3-offline/files/Windows%208.1/Net%20Framework%203.5%20offline%20installer%20Win_8.1.zip/download
    
  4.Net Framework 3.5 Offline Installer for Windows 10 and above
    https://sourceforge.net/projects/framework-3-offline/

Step No.2 Disconnect the Internet connection after you download.
Step No.3 Unzip and run the .Net Framework 3.5 offline installer
Step No.4 Run Setup.msi to install Dijkstra Simulator