package com.example.samd_assign2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    TextView txt2;
    TextView txt3;
    TextView txt4;
    TextView txt5;
    TextView txt6;
    TextView txt7;
    MyThread1 th1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = (TextView) findViewById(R.id.txt);
        txt2 = (TextView) findViewById(R.id.text2);
        txt3 = (TextView) findViewById(R.id.txt3);
        txt4 = (TextView) findViewById(R.id.txt4);
        txt5 = (TextView) findViewById(R.id.txt5);
        txt6 = (TextView) findViewById(R.id.txt6);
        txt7 = (TextView) findViewById(R.id.txt7);

        th1 = new MyThread1();
        txt.setText("After Creation of Thread:           " + th1.getState().toString());
        th1.start();
        txt2.setText("After Start() of Thread:              " + th1.getState().toString());
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        txt3.setText("After Sleep() of Thread:             " + th1.getState().toString());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        txt4.setText("After Wait() of Thread:               " + th1.getState().toString());
        th1.stop_wait();


        try {
            int[] nums = {11, 22, 33, 44, 55};
            MyThread3 myThread03 = new MyThread3(nums, Thread.currentThread(),txt5);
            myThread03.start();
            Thread.sleep(500);
            synchronized (nums) {

            }
        } catch (Exception ex) {
            Log.e("Test01", ex.getMessage());
        }
        txt6.setText("After Termination of Thread:     " + th1.getState().toString());
    }
}
