package com.example.samd_assign2;

public class MyThread1 extends Thread{

    int[] nums;
    Thread mainThread;
    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            i++;
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        synchronized (this) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void stop_wait(){
        synchronized (this){
            notifyAll();
        }
    }



}

