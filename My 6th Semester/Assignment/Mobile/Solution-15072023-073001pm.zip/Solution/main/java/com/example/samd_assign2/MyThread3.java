package com.example.samd_assign2;

import android.util.Log;
import android.widget.TextView;

public class MyThread3 extends Thread{
    int[] data;
    Thread mainThread;
    TextView txv;

    MyThread3(int[] data, Thread mainThread, TextView txv) {
        this.data = data;
        this.mainThread=mainThread;
        this.txv = txv;
    }

    @Override
    public void run() {
        try {
            synchronized (data) {
                Thread.sleep(1000);
                txv.setText("After Block() of Thread:             " + mainThread.getState().toString());
            }
        } catch (Exception ex) {
            Log.e("Test01", ex.getMessage());
        }

    }
}



