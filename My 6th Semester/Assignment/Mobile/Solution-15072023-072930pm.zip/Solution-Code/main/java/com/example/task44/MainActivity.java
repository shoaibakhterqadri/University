package com.example.task44;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    TextView volume;
    int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        volume = findViewById(R.id.volume);
    }
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int action, keycode;
        action = event.getAction();//user perform action up or down volume
        keycode = event.getKeyCode();// which button is press up or down
        switch (keycode) {
            case KeyEvent.KEYCODE_VOLUME_UP: {
                if (KeyEvent.ACTION_UP == action && count < 10) {
                    count++;
                    String run = String.valueOf(count);
                    volume.setText(run);
                }
                break;
            }
            case KeyEvent.KEYCODE_VOLUME_DOWN: {
                if (KeyEvent.ACTION_DOWN == action && count > 0) {
                    count--;
                    String run = String.valueOf(count);
                    volume.setText(run);
                }
                break;
            }

        }
        return super.dispatchKeyEvent(event);
    }
}


